/**
 * Patient & Doctor Registration API
 * POST /api/auth/register
 * 
 * Handles registration for both patients and doctors
 * Creates user in MongoDB and returns JWT token
 */

import { NextRequest, NextResponse } from 'next/server';
import { connectToDatabase } from '@/lib/db';
import { getCollections, initializeCollections } from '@/lib/models';
import { hashPassword, generateToken, setAuthCookie, apiSuccess, apiError } from '@/lib/auth';
import { patientRegisterSchema, doctorRegisterSchema } from '@/lib/validation';
import { ObjectId } from 'mongodb';

export async function POST(request: NextRequest) {
  try {
    // Get request body
    const body = await request.json();
    const { role } = body;

    // Validate role
    if (!role || !['patient', 'doctor'].includes(role)) {
      return NextResponse.json(
        apiError('Invalid role. Must be patient or doctor'),
        { status: 400 }
      );
    }

    // Validate input based on role
    let validatedData;
    if (role === 'patient') {
      const result = patientRegisterSchema.safeParse(body);
      if (!result.success) {
        return NextResponse.json(
          apiError(result.error.errors[0].message),
          { status: 400 }
        );
      }
      validatedData = result.data;
    } else {
      const result = doctorRegisterSchema.safeParse(body);
      if (!result.success) {
        return NextResponse.json(
          apiError(result.error.errors[0].message),
          { status: 400 }
        );
      }
      validatedData = result.data;
    }

    // Connect to database
    const { db } = await connectToDatabase();
    const { users, patients, doctors } = getCollections(db);

    // Initialize collections with indexes
    await initializeCollections(db);

    // Check if user already exists
    const existingUser = await users.findOne({ email: validatedData.email });
    if (existingUser) {
      return NextResponse.json(
        apiError('Email already registered'),
        { status: 409 }
      );
    }

    // Hash password
    const hashedPassword = await hashPassword(validatedData.password);

    // Create user in base collection
    const userResult = await users.insertOne({
      email: validatedData.email,
      password: hashedPassword,
      name: validatedData.name,
      phone: validatedData.phone,
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
    });

    const userId = userResult.insertedId;

    // Create role-specific profile
    if (role === 'patient') {
      await patients.insertOne({
        _id: userId,
        email: validatedData.email,
        password: hashedPassword,
        name: validatedData.name,
        phone: validatedData.phone,
        role: 'patient',
        dateOfBirth: validatedData.dateOfBirth,
        gender: validatedData.gender,
        address: validatedData.address,
        appointments: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    } else {
      // Doctor registration
      await doctors.insertOne({
        _id: userId,
        email: validatedData.email,
        password: hashedPassword,
        name: validatedData.name,
        phone: validatedData.phone,
        role: 'doctor',
        specialization: validatedData.specialization,
        qualifications: validatedData.qualifications,
        bio: '',
        clinicAddress: validatedData.clinicAddress,
        clinicPhone: validatedData.clinicPhone,
        consultationFee: validatedData.consultationFee,
        availabilitySchedule: [],
        appointments: [],
        averageRating: 0,
        reviewCount: 0,
        isApproved: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    // Generate JWT token
    const token = generateToken({
      userId: userId.toString(),
      email: validatedData.email,
      role,
    });

    // Set auth cookie
    const response = NextResponse.json(
      apiSuccess(
        {
          userId: userId.toString(),
          email: validatedData.email,
          name: validatedData.name,
          role,
        },
        'Registration successful'
      ),
      { status: 201 }
    );

    // Set cookie in response
    response.cookies.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60, // 30 days
      path: '/',
    });

    return response;
  } catch (error: any) {
    console.error('Registration error:', error);
    return NextResponse.json(
      apiError('Registration failed. Please try again.'),
      { status: 500 }
    );
  }
}
